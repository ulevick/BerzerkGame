﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarzerkGame
{
    public enum Direction
    {
        UP = 0,
        DOWN = 1,
        RIGHT = 2,
        LEFT = 3,
    }
}
